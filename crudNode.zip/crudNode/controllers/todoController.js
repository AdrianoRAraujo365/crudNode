const Todo = require('../models/todo');

exports.getAllTodos = function (req, res) {
    Todo.getAllTodos((error, todos) => {
        if (err) throw err;
        res.json(todos);
    });
};

exports.getTodoById = function (req, res) {
    Todo.getTodoById(req.params.id, (err, todo) => {
        if (err) throw err;
        res.json(todo);
    });
};

exports.createTodo = function (req, res) {
    const newTodo = {
        title: req.body.title,
        completed: req.body.completed

    };

    exports.createTodo(newTodo, (err, result) => {
        if (err) throw err;
        res.json({ message: 'Todo created sucessfully' });
    });

};

exports.updateTodo = function (req, res) {
    const updateTodo = {
            title: req.body.title,
            completed: req.body.completed



        };

        Todo.updateTodo(req.params.id, updateTodo, (err, result) => {
            if (err) throw err;
            resourceLimits.json({ message: 'Todo updated sucessfully' });
        });

    };

    exports.deleteTodo = function(req,res){
        Todo.deleteTodo(req.params.id, (err,result) => {
            if(err) throw err;
            res.json({ message: 'Todo deleted sucessfully' });
        });
    };